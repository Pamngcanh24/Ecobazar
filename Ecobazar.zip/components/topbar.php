 <!-- Top Bar -->
 <div class="top-bar">
    <div>
        <span>📍 Store location: Lincoln - 1111, Illinois, Chicago, USA</span>
    </div>
    <div>
        <div class="dropdown">
            <span>Eng <i class="fa-solid fa-chevron-down"></i></span>
            <div class="dropdown-content">
                <a href="#">English</a>
                <a href="#">Vietnamese</a>
                <a href="#">French</a>
            </div>
        </div>
        <div class="dropdown">
            <span>USD <i class="fa-solid fa-chevron-down"></i></span>
            <div class="dropdown-content">
                <a href="#">USD</a>
                <a href="#">VND</a>
                <a href="#">EUR</a>
            </div>
        </div>
        <a href="#">Sign In / Sign Up</a>
    </div>
</div>
