<?php
include 'includes/header.php';

// Lấy danh sách category
$categoryResult = $conn->query("SELECT id, name FROM categories");

// Tạo thư mục uploads nếu chưa có
$uploadDir = 'uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $old_price = $_POST['old_price'];
    $stock = $_POST['stock'];
    $description = $_POST['description'];

    $image = $_FILES['image']['name'];
    $tmpName = $_FILES['image']['tmp_name'];
    $targetPath = $uploadDir . basename($image);

    if (move_uploaded_file($tmpName, $targetPath)) {
        $stmt = $conn->prepare("INSERT INTO products (category_id, name, price, old_price, stock, description, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isddiss", $category_id, $name, $price, $old_price, $stock, $description, $image);

        if ($stmt->execute()) {
            echo "<script>alert('Thêm sản phẩm thành công!'); window.location.href='product.php';</script>";
        } else {
            echo "Lỗi: " . $stmt->error;
        }
    } else {
        echo "Lỗi khi tải ảnh lên.";
    }
}
?>
  <style>
    h1 { 
     margin: -40px 0 20px;
     color:rgb(42, 140, 45);
    }
    form { max-width: 600px; }
    label { 
      display: block;   
      margin-top: 15px;
      margin-bottom: 12px;
      font-weight: bold; 
      }
    input, select, textarea { 
      width: 100%; 
      padding: 8px; 
      margin-top: 5px; 
      border-radius: 5px; 
      border: 1px solid #ccc; 
      box-sizing: border-box; /* Thêm dòng này */
    }

  </style>
<main class="main-content-add">
 <nav class="breadcrumb">
      <a href="product.php">Product</a>
      <span class="separator">›</span>
      <span class="current">Create</span>
  </nav>

  <h1>Create Product</h1>
  <form action="" method="POST" enctype="multipart/form-data">

    <label>Category</label>
    <select name="category_id" required>
      <option value="">-- Select Category --</option>
      <?php while ($row = $categoryResult->fetch_assoc()): ?>
        <option value="<?= $row['id'] ?>"><?= $row['id'] . ' - ' . $row['name'] ?></option>
      <?php endwhile; ?>
    </select>

    <label>Name</label>
    <input type="text" name="name" required>

    <label>Price</label>
    <input type="number" name="price" step="0.01" required>

    <label>Old Price</label>
    <input type="number" name="old_price" step="0.01" required>

    <label>Stock</label>
    <input type="number" name="stock" required>

    <label>Description</label>
    <textarea name="description" rows="4" required></textarea>

    <label>Image</label>
    <input type="file" name="image" accept="image/*" required>

    
    <div class="form-actions">
        <button type="submit" class="btn-create">Create</button>
        <button type="submit" class="btn-another">Create & create another</button>
        <button type="button" class="btn-cancel" onclick="window.location.href='product.php'">Cancel</button>
    </div>
  </form>
</main>
<?php 
include 'includes/footer.php';
?>
