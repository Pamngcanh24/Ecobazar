<?php
// Giả sử user đã đăng nhập, lấy thông tin user từ session
session_start();

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
// Kết nối database
$conn = new mysqli('localhost', 'root', '', 'ecobazar');
if ($conn->connect_error) {
    die('Kết nối thất bại: ' . $conn->connect_error);
}


$user_id = $_SESSION['user_id'] ?? 1; // Test với user_id = 1

// Lấy thông tin người dùng
$user_query = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $user_query->fetch_assoc();

// Lấy lịch sử đơn hàng
$order_query = $conn->query("SELECT * FROM orders WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 5");

// Lấy thông tin đơn hàng gần nhất của user
$last_order_query = $conn->query("SELECT * FROM orders WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 1");
$last_order = $last_order_query->fetch_assoc();

//phân trang

// Phân trang
$limit = 4; // Số đơn hàng mỗi trang
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Đếm tổng số đơn hàng
$count_result = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE user_id = $user_id");
$total_orders = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_orders / $limit);

// Lấy danh sách đơn hàng có phân trang
$order_query = $conn->query("SELECT * FROM orders WHERE user_id = $user_id ORDER BY created_at DESC LIMIT $limit OFFSET $offset");

$pageTitle = "Dashboard";
include './includes/head.php'; 
?>
<style>
.pagination {
    margin-top: 20px;
    text-align: center;
}
.pagination a {
    display: inline-block;
    padding: 8px 12px;
    margin: 0 4px;
    background-color: #f0f0f0;
    color: #333;
    text-decoration: none;
    border-radius: 4px;
}
.pagination a.active {
    background-color: #00a859;
    color: white;
    font-weight: bold;
}
.pagination a:hover {
    background-color: #00a859;
    color: white;
}
</style>
   <!-- Breadcrumb -->
   <div class="breadcrumb-container">
        <div class="breadcrumb">
            <a href="homepage.php" class="home-icon" title="Home">
                <i class="fas fa-home" aria-hidden="true"></i>
            </a>
            <span> &gt; </span>
            <a href="#">Account</a>
            <span> &gt; </span>
            <a href="#" class="active">Dashboard</a>
        </div>
    </div>

    <?php include './includes/dash.php'; ?>

      <!-- Main Content -->
    <div class="main-content">
        <div class="card-container">
            <div class="card profile-info">
                 <img src="assets/image/Group.png" alt="Profile Picture">
                <p><?= isset($user['first_name']) ? htmlspecialchars($user['first_name']) : 'Chưa cập nhật' ?></p>
                <p>Customer</p>
                <!-- <p><?php echo $user['email']; ?></p> -->
                <a href="settings.php" class="edit-link">Edit Profile</a>
            </div>
       
        <div class="card address-info">
             <h3>Billing Address</h3>
             <p><?= htmlspecialchars($last_order['billing_address'] ?? 'Chưa cập nhật') ?></p>
             <p><?= htmlspecialchars($last_order['billing_email'] ?? 'Chưa cập nhật') ?></p>
             <p><?= htmlspecialchars($last_order['billing_phone'] ?? 'Chưa cập nhật') ?></p>

            <a href="settings.php" class="edit-link">Edit Address</a>
        </div>
        </div>

            <div class="card order-history">
                <div class="order-header">
                <h3>Recent Order History</h3>
                <a href="order-history.php" class="edit-link">View All</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                <?php while ($order = $order_query->fetch_assoc()): ?>
                    <tr>
                        <td>#<?php echo $order['id']; ?></td>
                        <td><?php echo date('d M, Y', strtotime($order['created_at'])); ?></td>
                        <td>$<?php echo number_format($order['total'], 2); ?></td>
                        <td><?php echo ucfirst($order['status']); ?></td>
                        <td><a href="order-detail.php?id=<?php echo $order['id']; ?>" class="edit-link">View Details</a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
                </table>
                  <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>"><i class="fas fa-chevron-left"></i></a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>" class="<?php echo ($i === $page) ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>"><i class="fas fa-chevron-right"></i></a>
        <?php endif; ?>
    </div>
            </div>
        </div>
    </div>

    <?php include './includes/footer.php'; ?>
    <script src="./assets/scrip.js"></script>
</body>
</html>
